import OpenAI from 'openai';
import { seoEnrichmentConfig } from '@/lib/seo-enrichment/config';
import {
  fetchCollectionForEnrichment,
  fetchProductForEnrichment,
} from '@/lib/seo-enrichment/db';
import { evaluateKorayCompliance } from '@/lib/seo-enrichment/koray-compliance';
import { buildKorayRuleBlock, selectKorayRules } from '@/lib/seo-enrichment/koray-retrieval';
import { buildKoraySystemPromptWithSelection } from '@/lib/seo-enrichment/koray';
import { log } from '@/lib/seo-enrichment/logger';
import { validateCollectionPayload, validateProductPayload } from '@/lib/seo-enrichment/validation';
import { findRelevantPages, getLinkableSitemap } from '@/lib/seo-enrichment/sitemap-cache';
import type { EnrichmentResult, QueueItem } from '@/lib/seo-enrichment/types';

function parseJson(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('No JSON object found in model response');
    return JSON.parse(match[0]);
  }
}

function estimateCost(inputTokens: number, outputTokens: number): number {
  return Number(
    (
      (inputTokens / 1000) * seoEnrichmentConfig.inputCostPer1k +
      (outputTokens / 1000) * seoEnrichmentConfig.outputCostPer1k
    ).toFixed(6)
  );
}

export class EnrichmentEngine {
  private readonly openai: OpenAI | null;

  constructor() {
    this.openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
  }

  async enrichQueueItem(
    item: QueueItem,
    serpAnalysis: Record<string, unknown>
  ): Promise<EnrichmentResult | null> {
    if (item.page_type === 'product') {
      return this.enrichProduct(item, serpAnalysis);
    }
    return this.enrichCollection(item, serpAnalysis);
  }

  private async generateJsonResponse(input: {
    system: string;
    userPayload: Record<string, unknown>;
  }): Promise<{ parsed: unknown; promptTokens: number; completionTokens: number }> {
    if (!this.openai) {
      return { parsed: {}, promptTokens: 0, completionTokens: 0 };
    }
    const completion = await this.openai.chat.completions.create({
      model: seoEnrichmentConfig.openaiModel,
      temperature: 0.2,
      max_tokens: seoEnrichmentConfig.openaiMaxTokens,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: input.system },
        { role: 'user', content: JSON.stringify(input.userPayload) },
      ],
    });
    const text = completion.choices[0]?.message?.content || '{}';
    return {
      parsed: parseJson(text),
      promptTokens: completion.usage?.prompt_tokens || 0,
      completionTokens: completion.usage?.completion_tokens || 0,
    };
  }

  private async enrichProduct(item: QueueItem, serpAnalysis: Record<string, unknown>): Promise<EnrichmentResult | null> {
    const row = await fetchProductForEnrichment(item.page_identifier);
    if (!row) return null;
    const selection = selectKorayRules('product', item.gsc_data);
    const selectedRuleBlock = buildKorayRuleBlock(selection);

    // Get linkable sitemap for internal linking suggestions
    const sitemap = await getLinkableSitemap();
    const relevantPages = findRelevantPages(
      item.canonical_path,
      row.title || '',
      row.product_type || '',
      Array.isArray(row.tags) ? row.tags : [],
      sitemap,
      15
    );

    const beforeContent = {
      meta_title: row.meta_title || '',
      meta_description: row.meta_description || '',
      title_override: row.title_override || '',
      description_html: row.description_html || '',
      top_description_html: row.top_description_html || '',
      bottom_description_html: row.bottom_description_html || '',
      bullet_points: row.bullet_points || [],
    };

    if (seoEnrichmentConfig.mode === 'dry-run' || !this.openai) {
      const fallback = validateProductPayload({
        meta_title: String(beforeContent.meta_title || `${row.title} | The Equestrian`).slice(0, 68),
        meta_description: String(beforeContent.meta_description || `Shop ${row.title} at The Equestrian.`).slice(0, 158),
        title_override: String(beforeContent.title_override || row.title || ''),
        description_html: String(beforeContent.description_html || row.description || ''),
        top_description_html: String(beforeContent.top_description_html || ''),
        bottom_description_html: String(beforeContent.bottom_description_html || ''),
        bullet_points: Array.isArray(beforeContent.bullet_points) ? beforeContent.bullet_points : [],
        internal_link_suggestions: [],
        reasoning: 'Dry-run fallback payload from existing values.',
      });
      const compliance = evaluateKorayCompliance('product', fallback);
      return {
        pageType: 'product',
        pageIdentifier: item.page_identifier,
        canonicalPath: item.canonical_path,
        beforeContent,
        payload: fallback,
        usage: { model: 'dry-run-fallback', inputTokens: 0, outputTokens: 0, costUsd: 0 },
        serpAnalysis,
        koray: {
          frameworkVersion: selection.frameworkVersion,
          ruleIdsUsed: selection.rules.map((r) => r.id),
          intent: selection.intent,
          compliance,
        },
      };
    }

    const baseSystem = buildKoraySystemPromptWithSelection(
      'You are an ecommerce SEO editor for product pages.',
      selectedRuleBlock,
      [
        'Return keys: meta_title, meta_description, title_override, description_html, top_description_html, bottom_description_html, bullet_points, internal_link_suggestions, reasoning.',
        'Meta title max 68 chars and meta description max 158 chars.',
        'bullet_points: array of plain strings in E-A-V format (e.g. "Material: Premium leather", "Size: 45cm"). Max 10 items, each under 180 chars.',
        'internal_link_suggestions: array of objects with {target_path: string, anchor_text: string, context: string, link_type?: string}. Suggest 3-5 contextually relevant internal links from the provided linkable_pages. Use link_type: "hub_spoke" for category pages, "contextual" for related products, "related" for complementary items. target_path must start with "/".',
        'description_html, top_description_html, bottom_description_html: rich HTML with <h2>/<h3> headings and extractive answers.',
        'Avoid fluff and generic claims; keep statements verifiable.',
      ]
    );
    const baseUserPayload = {
      page_type: 'product',
      page_identifier: item.page_identifier,
      canonical_path: item.canonical_path,
      performance: { gsc: item.gsc_data, ga4: item.ga4_data },
      serp_analysis: serpAnalysis,
      product: {
        title: row.title,
        vendor: row.vendor,
        product_type: row.product_type,
        tags: row.tags,
        description: row.description,
      },
      current_content: beforeContent,
      linkable_pages: relevantPages.map((p) => ({
        path: p.path,
        title: p.title,
        type: p.type,
        category: p.category,
      })),
      constraints: {
        meta_title_max: 68,
        meta_description_max: 158,
        bullet_points_max: 10,
        heading_style: 'question-led where context allows',
        extractive_answer_preference: true,
      },
    };

    let totalPromptTokens = 0;
    let totalCompletionTokens = 0;
    const firstPass = await this.generateJsonResponse({ system: baseSystem, userPayload: baseUserPayload });
    totalPromptTokens += firstPass.promptTokens;
    totalCompletionTokens += firstPass.completionTokens;
    let payload = validateProductPayload(firstPass.parsed);
    let compliance = evaluateKorayCompliance('product', payload);

    if (
      compliance.score < seoEnrichmentConfig.korayComplianceThreshold &&
      seoEnrichmentConfig.maxRegenerationAttempts > 0
    ) {
      const secondPass = await this.generateJsonResponse({
        system: baseSystem,
        userPayload: {
          ...baseUserPayload,
          previous_output: payload,
          compliance_feedback: compliance,
          instruction:
            'Regenerate to fix failed compliance checks while preserving factual accuracy and intent alignment.',
        },
      });
      totalPromptTokens += secondPass.promptTokens;
      totalCompletionTokens += secondPass.completionTokens;
      payload = validateProductPayload(secondPass.parsed);
      compliance = evaluateKorayCompliance('product', payload);
    }

    return {
      pageType: 'product',
      pageIdentifier: item.page_identifier,
      canonicalPath: item.canonical_path,
      beforeContent,
      payload,
      usage: {
        model: seoEnrichmentConfig.openaiModel,
        inputTokens: totalPromptTokens,
        outputTokens: totalCompletionTokens,
        costUsd: estimateCost(totalPromptTokens, totalCompletionTokens),
      },
      serpAnalysis,
      koray: {
        frameworkVersion: selection.frameworkVersion,
        ruleIdsUsed: selection.rules.map((r) => r.id),
        intent: selection.intent,
        compliance,
      },
    };
  }

  private async enrichCollection(item: QueueItem, serpAnalysis: Record<string, unknown>): Promise<EnrichmentResult | null> {
    const row = await fetchCollectionForEnrichment(item.page_identifier);
    if (!row) return null;
    const selection = selectKorayRules('collection', item.gsc_data);
    const selectedRuleBlock = buildKorayRuleBlock(selection);

    // Get linkable sitemap for internal linking suggestions
    const sitemap = await getLinkableSitemap();
    const relevantPages = findRelevantPages(
      item.canonical_path,
      row.h1_title || item.page_identifier,
      '',
      [],
      sitemap,
      20
    );

    const beforeContent = {
      h1_title: row.h1_title || '',
      meta_title: row.meta_title || '',
      meta_description: row.meta_description || '',
      short_description: row.short_description || '',
      long_description: row.long_description || '',
      faq_items: row.faq_items || [],
      related_categories: row.related_categories || [],
    };

    if (seoEnrichmentConfig.mode === 'dry-run' || !this.openai) {
      const fallback = validateCollectionPayload({
        ...beforeContent,
        short_description: String(beforeContent.short_description || `Shop ${row.h1_title} at The Equestrian.`),
        long_description: String(beforeContent.long_description || '<p>Content not generated in dry-run mode.</p>'),
        internal_link_suggestions: [],
        reasoning: 'Dry-run fallback payload from existing values.',
      });
      const compliance = evaluateKorayCompliance('collection', fallback);
      return {
        pageType: 'collection',
        pageIdentifier: item.page_identifier,
        canonicalPath: item.canonical_path,
        beforeContent,
        payload: fallback,
        usage: { model: 'dry-run-fallback', inputTokens: 0, outputTokens: 0, costUsd: 0 },
        serpAnalysis,
        koray: {
          frameworkVersion: selection.frameworkVersion,
          ruleIdsUsed: selection.rules.map((r) => r.id),
          intent: selection.intent,
          compliance,
        },
      };
    }

    const baseSystem = buildKoraySystemPromptWithSelection(
      'You are an ecommerce SEO strategist for collection and category hub pages.',
      selectedRuleBlock,
      [
        'Return keys: h1_title, meta_title, meta_description, short_description, long_description, faq_items, related_categories, internal_link_suggestions, reasoning.',
        'Meta title max 68 chars and meta description max 158 chars.',
        'faq_items: array of objects with {question: string, answer: string}. Max 8 items.',
        'related_categories: array of objects with {url: string, title: string, description?: string}. Max 8 items. URL must start with "/".',
        'internal_link_suggestions: array of objects with {target_path: string, anchor_text: string, context: string, link_type?: string}. Suggest 5-8 contextually relevant internal links from the provided linkable_pages. Use link_type: "hub_spoke" for child category pages, "contextual" for related products, "related" for sibling categories. target_path must start with "/".',
        'short_description and long_description: rich HTML with <h2>/<h3> headings for topical hub structure.',
        'Treat collection pages as topical hubs and support hub-spoke internal linking to build topical authority.',
        'Use FAQ and section flow that mirrors search sub-intents.',
      ]
    );
    const baseUserPayload = {
      page_type: 'collection',
      page_identifier: item.page_identifier,
      canonical_path: item.canonical_path,
      performance: { gsc: item.gsc_data, ga4: item.ga4_data },
      serp_analysis: serpAnalysis,
      collection: {
        url_path: row.url_path,
        parent_url: row.parent_url,
        category_level: row.category_level,
        status: row.status,
      },
      current_content: beforeContent,
      linkable_pages: relevantPages.map((p) => ({
        path: p.path,
        title: p.title,
        type: p.type,
        category: p.category,
      })),
      constraints: {
        meta_title_max: 68,
        meta_description_max: 158,
        faq_items_max: 8,
        heading_style: 'question-led h2/h3 for discoverability',
        extractive_answer_preference: true,
      },
    };

    let totalPromptTokens = 0;
    let totalCompletionTokens = 0;
    const firstPass = await this.generateJsonResponse({ system: baseSystem, userPayload: baseUserPayload });
    totalPromptTokens += firstPass.promptTokens;
    totalCompletionTokens += firstPass.completionTokens;
    let payload = validateCollectionPayload(firstPass.parsed);
    let compliance = evaluateKorayCompliance('collection', payload);

    if (
      compliance.score < seoEnrichmentConfig.korayComplianceThreshold &&
      seoEnrichmentConfig.maxRegenerationAttempts > 0
    ) {
      const secondPass = await this.generateJsonResponse({
        system: baseSystem,
        userPayload: {
          ...baseUserPayload,
          previous_output: payload,
          compliance_feedback: compliance,
          instruction:
            'Regenerate to fix failed compliance checks while preserving factual accuracy and intent alignment.',
        },
      });
      totalPromptTokens += secondPass.promptTokens;
      totalCompletionTokens += secondPass.completionTokens;
      payload = validateCollectionPayload(secondPass.parsed);
      compliance = evaluateKorayCompliance('collection', payload);
    }

    return {
      pageType: 'collection',
      pageIdentifier: item.page_identifier,
      canonicalPath: item.canonical_path,
      beforeContent,
      payload,
      usage: {
        model: seoEnrichmentConfig.openaiModel,
        inputTokens: totalPromptTokens,
        outputTokens: totalCompletionTokens,
        costUsd: estimateCost(totalPromptTokens, totalCompletionTokens),
      },
      serpAnalysis,
      koray: {
        frameworkVersion: selection.frameworkVersion,
        ruleIdsUsed: selection.rules.map((r) => r.id),
        intent: selection.intent,
        compliance,
      },
    };
  }

  reportMissingKeyWarning() {
    if (!process.env.OPENAI_API_KEY) {
      log('warn', 'OPENAI_API_KEY missing; enrichment engine will use dry-run fallback output');
    }
  }
}

